﻿namespace section2_GibbensProject
{
    partial class frmSection2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMessage = new System.Windows.Forms.Label();
            this.lblConvertFrom = new System.Windows.Forms.Label();
            this.lblBase = new System.Windows.Forms.Label();
            this.txtConvertFrom = new System.Windows.Forms.TextBox();
            this.txtBase = new System.Windows.Forms.TextBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnBase9 = new System.Windows.Forms.Button();
            this.btnBase6 = new System.Windows.Forms.Button();
            this.btnOctal = new System.Windows.Forms.Button();
            this.btnHex = new System.Windows.Forms.Button();
            this.btnBinary = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblMessage
            // 
            this.lblMessage.BackColor = System.Drawing.Color.Honeydew;
            this.lblMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.Location = new System.Drawing.Point(12, 195);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(397, 203);
            this.lblMessage.TabIndex = 0;
            this.lblMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblConvertFrom
            // 
            this.lblConvertFrom.BackColor = System.Drawing.Color.Honeydew;
            this.lblConvertFrom.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConvertFrom.Location = new System.Drawing.Point(12, 9);
            this.lblConvertFrom.Name = "lblConvertFrom";
            this.lblConvertFrom.Size = new System.Drawing.Size(236, 59);
            this.lblConvertFrom.TabIndex = 1;
            this.lblConvertFrom.Text = "Enter number that you want converted";
            // 
            // lblBase
            // 
            this.lblBase.BackColor = System.Drawing.Color.Honeydew;
            this.lblBase.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBase.Location = new System.Drawing.Point(10, 79);
            this.lblBase.Name = "lblBase";
            this.lblBase.Size = new System.Drawing.Size(236, 56);
            this.lblBase.TabIndex = 2;
            this.lblBase.Text = "Enter Base";
            // 
            // txtConvertFrom
            // 
            this.txtConvertFrom.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConvertFrom.Location = new System.Drawing.Point(265, 12);
            this.txtConvertFrom.Name = "txtConvertFrom";
            this.txtConvertFrom.Size = new System.Drawing.Size(144, 38);
            this.txtConvertFrom.TabIndex = 0;
            // 
            // txtBase
            // 
            this.txtBase.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBase.Location = new System.Drawing.Point(265, 79);
            this.txtBase.Name = "txtBase";
            this.txtBase.Size = new System.Drawing.Size(144, 38);
            this.txtBase.TabIndex = 1;
            // 
            // btnSubmit
            // 
            this.btnSubmit.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnSubmit.Font = new System.Drawing.Font("Times New Roman", 10.2F);
            this.btnSubmit.Location = new System.Drawing.Point(296, 144);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(113, 48);
            this.btnSubmit.TabIndex = 2;
            this.btnSubmit.Text = "S&ubmit";
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnExit.Font = new System.Drawing.Font("Times New Roman", 10.2F);
            this.btnExit.Location = new System.Drawing.Point(160, 144);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(113, 48);
            this.btnExit.TabIndex = 3;
            this.btnExit.TabStop = false;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnClear.Font = new System.Drawing.Font("Times New Roman", 10.2F);
            this.btnClear.Location = new System.Drawing.Point(17, 144);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(113, 48);
            this.btnClear.TabIndex = 2;
            this.btnClear.TabStop = false;
            this.btnClear.Text = "&Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnBase9
            // 
            this.btnBase9.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnBase9.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBase9.Location = new System.Drawing.Point(330, 418);
            this.btnBase9.Name = "btnBase9";
            this.btnBase9.Size = new System.Drawing.Size(79, 48);
            this.btnBase9.TabIndex = 7;
            this.btnBase9.Text = "Base &Nine";
            this.btnBase9.UseVisualStyleBackColor = false;
            this.btnBase9.Click += new System.EventHandler(this.btnBase9_Click);
            // 
            // btnBase6
            // 
            this.btnBase6.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnBase6.Font = new System.Drawing.Font("Times New Roman", 10.2F);
            this.btnBase6.Location = new System.Drawing.Point(254, 418);
            this.btnBase6.Name = "btnBase6";
            this.btnBase6.Size = new System.Drawing.Size(70, 48);
            this.btnBase6.TabIndex = 6;
            this.btnBase6.Text = "Base &Six";
            this.btnBase6.UseVisualStyleBackColor = false;
            this.btnBase6.Click += new System.EventHandler(this.btnBase6_Click);
            // 
            // btnOctal
            // 
            this.btnOctal.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnOctal.Font = new System.Drawing.Font("Times New Roman", 10.2F);
            this.btnOctal.Location = new System.Drawing.Point(178, 418);
            this.btnOctal.Name = "btnOctal";
            this.btnOctal.Size = new System.Drawing.Size(70, 48);
            this.btnOctal.TabIndex = 5;
            this.btnOctal.Text = "&Octal";
            this.btnOctal.UseVisualStyleBackColor = false;
            this.btnOctal.Click += new System.EventHandler(this.btnOctal_Click);
            // 
            // btnHex
            // 
            this.btnHex.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnHex.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnHex.Font = new System.Drawing.Font("Times New Roman", 10.2F);
            this.btnHex.Location = new System.Drawing.Point(102, 418);
            this.btnHex.Name = "btnHex";
            this.btnHex.Size = new System.Drawing.Size(70, 48);
            this.btnHex.TabIndex = 4;
            this.btnHex.Text = "&Hex";
            this.btnHex.UseVisualStyleBackColor = false;
            this.btnHex.Click += new System.EventHandler(this.btnHex_Click);
            // 
            // btnBinary
            // 
            this.btnBinary.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnBinary.Font = new System.Drawing.Font("Times New Roman", 10.2F);
            this.btnBinary.Location = new System.Drawing.Point(17, 418);
            this.btnBinary.Name = "btnBinary";
            this.btnBinary.Size = new System.Drawing.Size(79, 48);
            this.btnBinary.TabIndex = 3;
            this.btnBinary.Text = "&Binary";
            this.btnBinary.UseVisualStyleBackColor = false;
            this.btnBinary.Click += new System.EventHandler(this.btnBinary_Click);
            // 
            // frmSection2
            // 
            this.AcceptButton = this.btnSubmit;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(421, 481);
            this.Controls.Add(this.btnBinary);
            this.Controls.Add(this.btnHex);
            this.Controls.Add(this.btnOctal);
            this.Controls.Add(this.btnBase6);
            this.Controls.Add(this.btnBase9);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.txtBase);
            this.Controls.Add(this.txtConvertFrom);
            this.Controls.Add(this.lblBase);
            this.Controls.Add(this.lblConvertFrom);
            this.Controls.Add(this.lblMessage);
            this.Name = "frmSection2";
            this.Text = "Base Convert Gibbens";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.Label lblConvertFrom;
        private System.Windows.Forms.Label lblBase;
        private System.Windows.Forms.TextBox txtConvertFrom;
        private System.Windows.Forms.TextBox txtBase;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnBase9;
        private System.Windows.Forms.Button btnBase6;
        private System.Windows.Forms.Button btnOctal;
        private System.Windows.Forms.Button btnHex;
        private System.Windows.Forms.Button btnBinary;
    }
}