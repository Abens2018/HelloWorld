﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace section2_GibbensProject
{
    public partial class frmSection2 : Form
    {
        static void Main()
        {
            Application.Run(new frmSection2());
        }
        public frmSection2()
        {
            InitializeComponent();
        }

        private bool ErrorsHandleSubmit(string baseString, string converstionString)
        {
            try
            {
                int baseNum = Convert.ToInt32(baseString);

                if (baseNum < 2 || baseNum > 16)
                {
                    lblMessage.ForeColor = Color.Red;
                    lblMessage.Text = "The base needs to be between 2 and 16";
                    return false;
                }

                int converstionNum = Convert.ToInt32(converstionString);
                if (converstionNum >= 1)
                {
                    return true;
                }
                else
                {
                    lblMessage.ForeColor = Color.Red;
                    lblMessage.Text = "The converting number needs to be greater than 0";
                    return false;
                }
            }
            catch (Exception ex)
            {
                lblMessage.ForeColor = Color.Red;
                lblMessage.Text = ex.Message;
                return false;
            }
        }
        private bool ErrorsHandlePreset(string converstionString)
        {
            try
            {
                int converstionNum = Convert.ToInt32(converstionString);
                if (converstionNum >= 1)
                {
                    return true;
                }
                else
                {
                    lblMessage.ForeColor = Color.Red;
                    lblMessage.Text = "The converting number needs to be greater than 0";
                    return false;
                }
            }
            catch (Exception ex)
            {
                lblMessage.ForeColor = Color.Red;
                lblMessage.Text = ex.Message;
                return false;
            }
        }
        private string ConvertMethod(int baseNum, int converstionNum)
        {
            string answer = "";
            int remainder = 0;

            while (converstionNum > 0)
            {                
                remainder = converstionNum % baseNum;
                if (remainder == 10)
                {
                    answer += "A";
                }
                else if (remainder == 11)
                {
                    answer += "B";
                }
                else if (remainder == 12)
                {
                    answer += "C";
                }
                else if (remainder == 13)
                {
                    answer += "D";
                }
                else if (remainder == 14)
                {
                    answer += "E";
                }
                else if (remainder == 15)
                {
                    answer += "F";
                }
                else 
                {
                    answer = Convert.ToString(remainder) + answer;
                }
                converstionNum /= baseNum;
            }
            return answer;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lblMessage.ForeColor = Color.Black;
            lblMessage.Text = " ";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string baseString = "";
            string converstionString = "";

            baseString = txtBase.Text;
            converstionString = txtConvertFrom.Text;

            bool errorChecker = ErrorsHandleSubmit(baseString, converstionString);
            if (errorChecker == true)
            {
                int baseNum = Convert.ToInt32(baseString);
                int converstionNum = Convert.ToInt32(converstionString);
                string answer = ConvertMethod(baseNum, converstionNum);
                lblMessage.ForeColor = Color.Black;
                lblMessage.Text = answer;
            }
        }

        private void btnBinary_Click(object sender, EventArgs e)
        {
            string converstionString = "";

            converstionString = txtConvertFrom.Text;

            bool errorChecker = ErrorsHandlePreset(converstionString);
            if (errorChecker == true)
            {
                int baseNum = 2;
                int converstionNum = Convert.ToInt32(converstionString);
                string answer = ConvertMethod(baseNum, converstionNum);
                lblMessage.ForeColor = Color.Black;
                lblMessage.Text = answer;
            }
        }

        private void btnHex_Click(object sender, EventArgs e)
        {
            string converstionString = "";

            converstionString = txtConvertFrom.Text;

            bool errorChecker = ErrorsHandlePreset(converstionString);
            if (errorChecker == true)
            {
                int baseNum = 16;
                int converstionNum = Convert.ToInt32(converstionString);
                string answer = ConvertMethod(baseNum, converstionNum);
                lblMessage.ForeColor = Color.Black;
                lblMessage.Text = answer;
            }
        }

        private void btnOctal_Click(object sender, EventArgs e)
        {
            string converstionString = "";

            converstionString = txtConvertFrom.Text;

            bool errorChecker = ErrorsHandlePreset(converstionString);
            if (errorChecker == true)
            {
                int baseNum = 8;
                int converstionNum = Convert.ToInt32(converstionString);
                string answer = ConvertMethod(baseNum, converstionNum);
                lblMessage.ForeColor = Color.Black;
                lblMessage.Text = answer;
            }
        }

        private void btnBase6_Click(object sender, EventArgs e)
        {
            string converstionString = "";

            converstionString = txtConvertFrom.Text;

            bool errorChecker = ErrorsHandlePreset(converstionString);
            if (errorChecker == true)
            {
                int baseNum = 6;
                int converstionNum = Convert.ToInt32(converstionString);
                string answer = ConvertMethod(baseNum, converstionNum);
                lblMessage.ForeColor = Color.Black;
                lblMessage.Text = answer;
            }
        }

        private void btnBase9_Click(object sender, EventArgs e)
        {
            string converstionString = "";

            converstionString = txtConvertFrom.Text;

            bool errorChecker = ErrorsHandlePreset(converstionString);
            if (errorChecker == true)
            {
                int baseNum = 9;
                int converstionNum = Convert.ToInt32(converstionString);
                string answer = ConvertMethod(baseNum, converstionNum);
                lblMessage.ForeColor = Color.Black;
                lblMessage.Text = answer;
            }
        }
    }
}
