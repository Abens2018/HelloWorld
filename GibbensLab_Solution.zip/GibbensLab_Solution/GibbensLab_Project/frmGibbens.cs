﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/* Name : Autumn Gibbens
 * Course : ITD 2343 – Object Oriented Programming with C#
 * Instructor: Mark L. Pranger
 * Due Date: September 23, 2025
 */

namespace GibbensLab_Project
{
    public partial class frmGibbens : Form
    {
        public frmGibbens()
        {
            InitializeComponent();
        }
        static void Main()
        {
            Application.Run(new frmGibbens());
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            //This button turns the label white, the text color black, and makes the text into nothing.
            lblTheDominator.Text = " ";
            lblTheDominator.BackColor = btnClear.BackColor;
            lblTheDominator.ForeColor = btnClear.ForeColor;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //This button closes the program
            this.Close();
        }

        private void btnRed_Click(object sender, EventArgs e)
        {
            //This button turns the label Red and makes the text color white.
            lblTheDominator.BackColor = btnRed.BackColor;
            lblTheDominator.ForeColor = btnBlack.ForeColor;
        }

        private void btnOrange_Click(object sender, EventArgs e)
        {
            //This button turns the label Red and makes the text color black.
            lblTheDominator.BackColor= btnOrange.BackColor;
            lblTheDominator.ForeColor = btnRed.ForeColor;
        }

        private void btnYellow_Click(object sender, EventArgs e)
        {
            lblTheDominator.BackColor = btnYellow.BackColor;
            lblTheDominator.ForeColor = btnRed.ForeColor;
        }

        private void btnGreen_Click(object sender, EventArgs e)
        {
            lblTheDominator.BackColor = btnGreen.BackColor;
            lblTheDominator.ForeColor = btnBlack.ForeColor;
        }

        private void btnCyan_Click(object sender, EventArgs e)
        {
            lblTheDominator.BackColor = btnCyan.BackColor;
            lblTheDominator.ForeColor = btnRed.ForeColor;
        }

        private void btnBlue_Click(object sender, EventArgs e)
        {
            lblTheDominator.BackColor = btnBlue.BackColor;
            lblTheDominator.ForeColor = btnBlack.ForeColor;
        }

        private void btnPurple_Click(object sender, EventArgs e)
        {
            lblTheDominator.BackColor = btnPurple.BackColor;
            lblTheDominator.ForeColor = btnBlack.ForeColor;
        }
        private void btnBlack_Click(object sender, EventArgs e)
        {
            lblTheDominator.BackColor = btnBlack.BackColor;
            lblTheDominator.ForeColor = btnBlack.ForeColor;
        }

        private void btnGrey_Click(object sender, EventArgs e)
        {
            lblTheDominator.BackColor = btnGrey.BackColor;
            lblTheDominator.ForeColor = btnBlack.ForeColor;
        }

        private void btnDigit1_Click(object sender, EventArgs e)
        {
            //This button writes the 1 in the label.
            lblTheDominator.Text = "1";
        }

        private void btnDigit2_Click(object sender, EventArgs e)
        {
            //This button writes the 2 in the label.
            lblTheDominator.Text = "2";
        }

        private void btnDigit3_Click(object sender, EventArgs e)
        {
            lblTheDominator.Text = "3";
        }

        private void btnDigit4_Click(object sender, EventArgs e)
        {
            lblTheDominator.Text = "4";
        }

        private void btnDigit5_Click(object sender, EventArgs e)
        {
            lblTheDominator.Text = "5";
        }

        private void btnDigit6_Click(object sender, EventArgs e)
        {
            lblTheDominator.Text = "6";
        }

        private void btnDigit7_Click(object sender, EventArgs e)
        {
            lblTheDominator.Text = "7";
        }

        private void btnDigit8_Click(object sender, EventArgs e)
        {
            lblTheDominator.Text = "8";
        }

        private void btnDigit9_Click(object sender, EventArgs e)
        {
            lblTheDominator.Text = "9";
        }
    }
}
