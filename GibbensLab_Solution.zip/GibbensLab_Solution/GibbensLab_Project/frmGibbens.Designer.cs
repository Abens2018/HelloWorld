﻿namespace GibbensLab_Project
{
    partial class frmGibbens
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTheDominator = new System.Windows.Forms.Label();
            this.btnRed = new System.Windows.Forms.Button();
            this.btnOrange = new System.Windows.Forms.Button();
            this.btnYellow = new System.Windows.Forms.Button();
            this.btnGreen = new System.Windows.Forms.Button();
            this.btnCyan = new System.Windows.Forms.Button();
            this.btnBlue = new System.Windows.Forms.Button();
            this.btnPurple = new System.Windows.Forms.Button();
            this.btnBlack = new System.Windows.Forms.Button();
            this.btnGrey = new System.Windows.Forms.Button();
            this.btnDigit1 = new System.Windows.Forms.Button();
            this.btnDigit2 = new System.Windows.Forms.Button();
            this.btnDigit3 = new System.Windows.Forms.Button();
            this.btnDigit4 = new System.Windows.Forms.Button();
            this.btnDigit5 = new System.Windows.Forms.Button();
            this.btnDigit6 = new System.Windows.Forms.Button();
            this.btnDigit7 = new System.Windows.Forms.Button();
            this.btnDigit8 = new System.Windows.Forms.Button();
            this.btnDigit9 = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTheDominator
            // 
            this.lblTheDominator.BackColor = System.Drawing.Color.White;
            this.lblTheDominator.Font = new System.Drawing.Font("Microsoft Sans Serif", 124.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTheDominator.Location = new System.Drawing.Point(12, 220);
            this.lblTheDominator.Name = "lblTheDominator";
            this.lblTheDominator.Size = new System.Drawing.Size(258, 200);
            this.lblTheDominator.TabIndex = 0;
            this.lblTheDominator.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnRed
            // 
            this.btnRed.BackColor = System.Drawing.Color.Red;
            this.btnRed.Location = new System.Drawing.Point(12, 30);
            this.btnRed.Name = "btnRed";
            this.btnRed.Size = new System.Drawing.Size(64, 41);
            this.btnRed.TabIndex = 1;
            this.btnRed.UseVisualStyleBackColor = false;
            this.btnRed.Click += new System.EventHandler(this.btnRed_Click);
            // 
            // btnOrange
            // 
            this.btnOrange.BackColor = System.Drawing.Color.Orange;
            this.btnOrange.Location = new System.Drawing.Point(111, 30);
            this.btnOrange.Name = "btnOrange";
            this.btnOrange.Size = new System.Drawing.Size(64, 41);
            this.btnOrange.TabIndex = 2;
            this.btnOrange.UseVisualStyleBackColor = false;
            this.btnOrange.Click += new System.EventHandler(this.btnOrange_Click);
            // 
            // btnYellow
            // 
            this.btnYellow.BackColor = System.Drawing.Color.Yellow;
            this.btnYellow.Location = new System.Drawing.Point(206, 30);
            this.btnYellow.Name = "btnYellow";
            this.btnYellow.Size = new System.Drawing.Size(64, 41);
            this.btnYellow.TabIndex = 3;
            this.btnYellow.UseVisualStyleBackColor = false;
            this.btnYellow.Click += new System.EventHandler(this.btnYellow_Click);
            // 
            // btnGreen
            // 
            this.btnGreen.BackColor = System.Drawing.Color.Green;
            this.btnGreen.Location = new System.Drawing.Point(12, 91);
            this.btnGreen.Name = "btnGreen";
            this.btnGreen.Size = new System.Drawing.Size(64, 41);
            this.btnGreen.TabIndex = 4;
            this.btnGreen.UseVisualStyleBackColor = false;
            this.btnGreen.Click += new System.EventHandler(this.btnGreen_Click);
            // 
            // btnCyan
            // 
            this.btnCyan.BackColor = System.Drawing.Color.Cyan;
            this.btnCyan.Location = new System.Drawing.Point(111, 91);
            this.btnCyan.Name = "btnCyan";
            this.btnCyan.Size = new System.Drawing.Size(64, 41);
            this.btnCyan.TabIndex = 5;
            this.btnCyan.UseVisualStyleBackColor = false;
            this.btnCyan.Click += new System.EventHandler(this.btnCyan_Click);
            // 
            // btnBlue
            // 
            this.btnBlue.BackColor = System.Drawing.Color.Blue;
            this.btnBlue.Location = new System.Drawing.Point(206, 91);
            this.btnBlue.Name = "btnBlue";
            this.btnBlue.Size = new System.Drawing.Size(64, 41);
            this.btnBlue.TabIndex = 6;
            this.btnBlue.UseVisualStyleBackColor = false;
            this.btnBlue.Click += new System.EventHandler(this.btnBlue_Click);
            // 
            // btnPurple
            // 
            this.btnPurple.BackColor = System.Drawing.Color.Purple;
            this.btnPurple.Location = new System.Drawing.Point(12, 157);
            this.btnPurple.Name = "btnPurple";
            this.btnPurple.Size = new System.Drawing.Size(64, 41);
            this.btnPurple.TabIndex = 7;
            this.btnPurple.UseVisualStyleBackColor = false;
            this.btnPurple.Click += new System.EventHandler(this.btnPurple_Click);
            // 
            // btnBlack
            // 
            this.btnBlack.BackColor = System.Drawing.Color.Black;
            this.btnBlack.ForeColor = System.Drawing.Color.White;
            this.btnBlack.Location = new System.Drawing.Point(111, 157);
            this.btnBlack.Name = "btnBlack";
            this.btnBlack.Size = new System.Drawing.Size(64, 41);
            this.btnBlack.TabIndex = 8;
            this.btnBlack.UseVisualStyleBackColor = false;
            this.btnBlack.Click += new System.EventHandler(this.btnBlack_Click);
            // 
            // btnGrey
            // 
            this.btnGrey.BackColor = System.Drawing.Color.Gray;
            this.btnGrey.Location = new System.Drawing.Point(206, 157);
            this.btnGrey.Name = "btnGrey";
            this.btnGrey.Size = new System.Drawing.Size(64, 41);
            this.btnGrey.TabIndex = 9;
            this.btnGrey.UseVisualStyleBackColor = false;
            this.btnGrey.Click += new System.EventHandler(this.btnGrey_Click);
            // 
            // btnDigit1
            // 
            this.btnDigit1.BackColor = System.Drawing.Color.White;
            this.btnDigit1.Location = new System.Drawing.Point(12, 463);
            this.btnDigit1.Name = "btnDigit1";
            this.btnDigit1.Size = new System.Drawing.Size(64, 41);
            this.btnDigit1.TabIndex = 10;
            this.btnDigit1.Text = "1";
            this.btnDigit1.UseVisualStyleBackColor = false;
            this.btnDigit1.Click += new System.EventHandler(this.btnDigit1_Click);
            // 
            // btnDigit2
            // 
            this.btnDigit2.BackColor = System.Drawing.Color.White;
            this.btnDigit2.Location = new System.Drawing.Point(111, 463);
            this.btnDigit2.Name = "btnDigit2";
            this.btnDigit2.Size = new System.Drawing.Size(64, 41);
            this.btnDigit2.TabIndex = 11;
            this.btnDigit2.Text = "2";
            this.btnDigit2.UseVisualStyleBackColor = false;
            this.btnDigit2.Click += new System.EventHandler(this.btnDigit2_Click);
            // 
            // btnDigit3
            // 
            this.btnDigit3.BackColor = System.Drawing.Color.White;
            this.btnDigit3.Location = new System.Drawing.Point(206, 463);
            this.btnDigit3.Name = "btnDigit3";
            this.btnDigit3.Size = new System.Drawing.Size(64, 41);
            this.btnDigit3.TabIndex = 12;
            this.btnDigit3.Text = "3";
            this.btnDigit3.UseVisualStyleBackColor = false;
            this.btnDigit3.Click += new System.EventHandler(this.btnDigit3_Click);
            // 
            // btnDigit4
            // 
            this.btnDigit4.BackColor = System.Drawing.Color.White;
            this.btnDigit4.Location = new System.Drawing.Point(12, 544);
            this.btnDigit4.Name = "btnDigit4";
            this.btnDigit4.Size = new System.Drawing.Size(64, 41);
            this.btnDigit4.TabIndex = 13;
            this.btnDigit4.Text = "4";
            this.btnDigit4.UseVisualStyleBackColor = false;
            this.btnDigit4.Click += new System.EventHandler(this.btnDigit4_Click);
            // 
            // btnDigit5
            // 
            this.btnDigit5.BackColor = System.Drawing.Color.White;
            this.btnDigit5.Location = new System.Drawing.Point(111, 544);
            this.btnDigit5.Name = "btnDigit5";
            this.btnDigit5.Size = new System.Drawing.Size(64, 41);
            this.btnDigit5.TabIndex = 14;
            this.btnDigit5.Text = "5";
            this.btnDigit5.UseVisualStyleBackColor = false;
            this.btnDigit5.Click += new System.EventHandler(this.btnDigit5_Click);
            // 
            // btnDigit6
            // 
            this.btnDigit6.BackColor = System.Drawing.Color.White;
            this.btnDigit6.Location = new System.Drawing.Point(206, 544);
            this.btnDigit6.Name = "btnDigit6";
            this.btnDigit6.Size = new System.Drawing.Size(64, 41);
            this.btnDigit6.TabIndex = 15;
            this.btnDigit6.Text = "6";
            this.btnDigit6.UseVisualStyleBackColor = false;
            this.btnDigit6.Click += new System.EventHandler(this.btnDigit6_Click);
            // 
            // btnDigit7
            // 
            this.btnDigit7.BackColor = System.Drawing.Color.White;
            this.btnDigit7.Location = new System.Drawing.Point(12, 619);
            this.btnDigit7.Name = "btnDigit7";
            this.btnDigit7.Size = new System.Drawing.Size(64, 41);
            this.btnDigit7.TabIndex = 16;
            this.btnDigit7.Text = "7";
            this.btnDigit7.UseVisualStyleBackColor = false;
            this.btnDigit7.Click += new System.EventHandler(this.btnDigit7_Click);
            // 
            // btnDigit8
            // 
            this.btnDigit8.BackColor = System.Drawing.Color.White;
            this.btnDigit8.Location = new System.Drawing.Point(111, 619);
            this.btnDigit8.Name = "btnDigit8";
            this.btnDigit8.Size = new System.Drawing.Size(64, 41);
            this.btnDigit8.TabIndex = 17;
            this.btnDigit8.Text = "8";
            this.btnDigit8.UseVisualStyleBackColor = false;
            this.btnDigit8.Click += new System.EventHandler(this.btnDigit8_Click);
            // 
            // btnDigit9
            // 
            this.btnDigit9.BackColor = System.Drawing.Color.White;
            this.btnDigit9.Location = new System.Drawing.Point(206, 619);
            this.btnDigit9.Name = "btnDigit9";
            this.btnDigit9.Size = new System.Drawing.Size(64, 41);
            this.btnDigit9.TabIndex = 18;
            this.btnDigit9.Text = "9";
            this.btnDigit9.UseVisualStyleBackColor = false;
            this.btnDigit9.Click += new System.EventHandler(this.btnDigit9_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.White;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Location = new System.Drawing.Point(12, 689);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(120, 41);
            this.btnExit.TabIndex = 19;
            this.btnExit.Text = "&Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.White;
            this.btnClear.Location = new System.Drawing.Point(150, 689);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(120, 41);
            this.btnClear.TabIndex = 20;
            this.btnClear.Text = "&Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // frmGibbens
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(282, 753);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnDigit9);
            this.Controls.Add(this.btnDigit8);
            this.Controls.Add(this.btnDigit7);
            this.Controls.Add(this.btnDigit6);
            this.Controls.Add(this.btnDigit5);
            this.Controls.Add(this.btnDigit4);
            this.Controls.Add(this.btnDigit3);
            this.Controls.Add(this.btnDigit2);
            this.Controls.Add(this.btnDigit1);
            this.Controls.Add(this.btnGrey);
            this.Controls.Add(this.btnBlack);
            this.Controls.Add(this.btnPurple);
            this.Controls.Add(this.btnBlue);
            this.Controls.Add(this.btnCyan);
            this.Controls.Add(this.btnGreen);
            this.Controls.Add(this.btnYellow);
            this.Controls.Add(this.btnOrange);
            this.Controls.Add(this.btnRed);
            this.Controls.Add(this.lblTheDominator);
            this.Name = "frmGibbens";
            this.Text = "Gibbens - Programming Lab";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblTheDominator;
        private System.Windows.Forms.Button btnRed;
        private System.Windows.Forms.Button btnOrange;
        private System.Windows.Forms.Button btnYellow;
        private System.Windows.Forms.Button btnGreen;
        private System.Windows.Forms.Button btnCyan;
        private System.Windows.Forms.Button btnBlue;
        private System.Windows.Forms.Button btnPurple;
        private System.Windows.Forms.Button btnBlack;
        private System.Windows.Forms.Button btnGrey;
        private System.Windows.Forms.Button btnDigit1;
        private System.Windows.Forms.Button btnDigit2;
        private System.Windows.Forms.Button btnDigit3;
        private System.Windows.Forms.Button btnDigit4;
        private System.Windows.Forms.Button btnDigit5;
        private System.Windows.Forms.Button btnDigit6;
        private System.Windows.Forms.Button btnDigit7;
        private System.Windows.Forms.Button btnDigit8;
        private System.Windows.Forms.Button btnDigit9;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnClear;
    }
}