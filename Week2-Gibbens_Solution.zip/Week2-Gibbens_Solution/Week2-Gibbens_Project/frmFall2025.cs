﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/* Name : Autumn Gibbens
 * Course : ITD 2343 – Object Oriented Programming with C#
 * Instructor: Mark L. Pranger
 * Due Date: September 16, 2025
 */

namespace Week2_Gibbens_Project
{
    public partial class frmFall2025 : Form
    {
        static void Main()
        {
            Application.Run(new frmFall2025());
        }
        public frmFall2025()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void lblHold_Click(object sender, EventArgs e)
        {

        }

        private void btnWipe_Click(object sender, EventArgs e)
        {
            // Makes the holding lable blank
            lblHold.Text = "";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Puts the string in the text box into the holding label
            string text = txtEnter.Text;
            lblHold.Text = text;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            // Makes the enter text box blank
            txtEnter.Text = string.Empty;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // Closes the program
            this.Close();
        }
    }
}
