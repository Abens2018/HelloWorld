﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/* Name : Autumn Gibbens
 * Course : ITD 2343 – Object Oriented Programming with C#
 * Instructor: Mark L. Pranger
 * Due Date: November 4, 2025
 */

namespace Week8Project_Gibbens
{
    public partial class frmCollections : Form
    {
        int[] lists;
        int currentIndex = 0;

        static void Main()
        {
            Application.Run(new frmCollections());
        }
        public frmCollections()
        {
            InitializeComponent();

        }

        private bool errorAdd(string number)
        {
            
           
            if (number == "")
            {
                lblStatistics.Text = "A number needs to be added.";
                return false;
            }
            else
            {
                try
                {
                    int iNumber = Convert.ToInt32(number);
                    if (iNumber < -1217)
                    {
                        lblStatistics.Text = "The number is to small.";
                        return false;
                    }
                    else if (iNumber > 1217)
                    {
                        lblStatistics.Text = "The number is to big.";
                        return false;
                    }
                    else
                    {
                        return true;
                    }
                }
                catch (Exception ex)
                {
                    lblStatistics.Text = "The number needs to be an interger.";
                    return false;
                }
            }
        }
        private void btnShow_Click(object sender, EventArgs e)
        {
            int sum = 0;
            foreach (int item in lists)
            {
                sum += item;
                lblCollection.Text += item + "\n";
            }
            int average = sum / lists.Length;
            int[] sortedList;
            sortedList = new int[lists.Length];
            Array.Copy(lists, sortedList, lists.Length);
            Array.Sort(sortedList);
            int least = sortedList[0];
            int great = sortedList[16];

            lblStatistics.Text = "Average: " + average +
                "\nGreatest: " + great +
                "\nLeast: " + least +
                "\n Total: " + lists.Length;
            for (int i = 0; i < 17; i++)
            {
                lists[i] = 0;
            }
            currentIndex = 0;
        }


        private void btnAdd_Click(object sender, EventArgs e)
        {
            string number = txtNumber.Text;
            bool errorVariable = errorAdd(number);
            if (errorVariable == true)
            {
                int iNumber = Convert.ToInt32(number);
                if (lists == null)
                {
                    lists = new int[17];
                    currentIndex = 0;
                }
                if (currentIndex < lists.Length)
                {
                    lists[currentIndex] = iNumber;
                    currentIndex++;
                }
                else
                {
                    lblStatistics.Text = "The collection is full";
                    return;
                }
                txtNumber.Text = "";
                
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtNumber.Text = "";
            lblCollection.Text = "";
            lblStatistics.Text = "";
            for (int i = 0; i < 17; i++)
            {
                lists[i] = 0;
            }
            currentIndex = 0;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
