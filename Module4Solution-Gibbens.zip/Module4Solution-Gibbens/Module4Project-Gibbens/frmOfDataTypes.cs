﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/* Name : Autumn Gibbens
 * Course : ITD 2343 – Object Oriented Programming with C#
 * Instructor: Mark L. Pranger
 * Due Date: September 16, 2025
 */

namespace Module4Project_Gibbens
{
    public partial class frmOfDataTypes : Form
    {
        static void Main()
        {
            Application.Run(new frmOfDataTypes());
        }
        public frmOfDataTypes()
        {
            InitializeComponent();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            //Clears the Main Label
            lblMain.Text = " ";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //Exits the program
            this.Close();
        }

        private void btnByte_Click(object sender, EventArgs e)
        {
            // Adds together to bytes
            byte leftOperand = 1;
            byte rightOperand = 3;
            int results;

            results = leftOperand + rightOperand;

            lblMain.Text = string.Format("{0:d} + {1:d} = {2:d}", leftOperand, 
                rightOperand, results);
        }

        private void btnShort_Click(object sender, EventArgs e)
        {
            // Subtract two shorts
            short leftOperand = 7;
            short rightOperand = 2;
            int results;

            results = leftOperand - rightOperand;

            lblMain.Text = string.Format("{0:d} - {1:d} = {2:d}", leftOperand,
                rightOperand, results);
        }

        private void btnInt_Click(object sender, EventArgs e)
        {
            // Divide of two ints
            int leftOperand = 12;
            int rightOperand = 6;
            int results;

            results = leftOperand / rightOperand;

            lblMain.Text = string.Format("{0:d} / {1:d} = {2:d}", leftOperand,
                rightOperand, results);
        }

        private void btnLong_Click(object sender, EventArgs e)
        {
            // Modulus of two Longs
            long leftOperand = 2000000000;
            long rightOperand = 1000132;
            long results;

            results = leftOperand % rightOperand;

            lblMain.Text = string.Format("{0:d} % {1:d} = {2:d}", leftOperand,
                rightOperand, results);
        }

        private void btnFloat_Click(object sender, EventArgs e)
        {
            // Modulus of two Floats
            float leftOperand = 5.215464f;
            float rightOperand = 2.16489f;
            float results;

            results = leftOperand % rightOperand;

            lblMain.Text = string.Format("{0:f6} % {1:f6} = {2:f6}", leftOperand,
                rightOperand, results);
        }

        private void btnDouble_Click(object sender, EventArgs e)
        {
            // Devide two doubles
            double leftOperand = 36;
            double rightOperand = 33;
            double results;

            results = leftOperand / rightOperand;

            lblMain.Text = string.Format("{0:f} / {1:f} = {2:f13}", leftOperand,
                rightOperand, results);
        }

        private void btnDecimal_Click(object sender, EventArgs e)
        {
            // Subtract two Decimals
            decimal leftOperand = 8.51456154843127861154m;
            decimal rightOperand = 6.82156431568348913245m;
            decimal results;

            results = leftOperand * rightOperand;

            lblMain.Text = string.Format("{0:f27} * {1:f27} = {2:f27}", leftOperand,
                rightOperand, results);
        }

        private void btnPow_Click(object sender, EventArgs e)
        {
            // Find a number squared
            int number = 5;
            int results;

            results = number * number;

            lblMain.Text = string.Format("{0:d} squared is {1:d}", number, results);
        }

        private void btnRound_Click(object sender, EventArgs e)
        {
            // Round the number 5.4
            float number = 5.4f;
            int results;

            results = (int)number;
            lblMain.Text = string.Format("{0:f} rounded is {1:d}", number, results);
        }

        private void btnSqrt_Click(object sender, EventArgs e)
        {
            // Find the square root of a number
            int number = 25;
            double results;

            results = Math.Sqrt(number);

            lblMain.Text = string.Format("{0:d} squared is {1:f}", number, results);
        }
    }
}
