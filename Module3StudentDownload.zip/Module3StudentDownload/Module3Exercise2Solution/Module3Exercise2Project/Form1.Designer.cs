﻿namespace Module3Exercise2Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            // I changed button2 to btnBlue, button3 to btnR, button4 to btnL
            // and the lable to lblMessage
            this.btnRed = new System.Windows.Forms.Button();
            this.btnBlue = new System.Windows.Forms.Button();
            this.btnR = new System.Windows.Forms.Button();
            this.btnL = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.lblMessage = new System.Windows.Forms.Label();
            this.SuspendLayout();

            // 
            // btnRed
            // 
            this.btnRed.BackColor = System.Drawing.Color.Red;
            //I changed the font color to Red
            this.btnRed.ForeColor = System.Drawing.Color.Red;
            //I changed the positioning
            this.btnRed.Location = new System.Drawing.Point(21, 16);
            this.btnRed.Name = "btnRed";
            this.btnRed.Size = new System.Drawing.Size(93, 45);
            this.btnRed.TabIndex = 0;
            //I added the hotkey
            this.btnRed.Text = "RE&D";
            this.btnRed.UseVisualStyleBackColor = false;
            this.btnRed.Click += new System.EventHandler(this.btnRed_Click);

            // 
            // btnBlue 
            // 
            //I changed button2 to btnBlue
            this.btnBlue.BackColor = System.Drawing.Color.Blue;
            //I changed the font color to blue
            this.btnBlue.ForeColor = System.Drawing.Color.Blue;
            //I changed the positioning
            this.btnBlue.Location = new System.Drawing.Point(376, 16);
            this.btnBlue.Name = "btnBlue";
            this.btnBlue.Size = new System.Drawing.Size(93, 45);
            this.btnBlue.TabIndex = 1;
            //I added the hotkey
            this.btnBlue.Text = "&BLUE";
            this.btnBlue.UseVisualStyleBackColor = false;
            this.btnBlue.Click += new System.EventHandler(this.btnBlue_Click);

            // 
            // btnR
            // 
            //I changed button3 to btnR
            //I changed the positioning
            this.btnR.Location = new System.Drawing.Point(376, 155);
            this.btnR.Name = "btnR";
            this.btnR.Size = new System.Drawing.Size(93, 45);
            this.btnR.TabIndex = 3;
            //I added the hotkey
            this.btnR.Text = "&R";
            this.btnR.UseVisualStyleBackColor = true;
            this.btnR.Click += new System.EventHandler(this.btnR_Click);

            // 
            // btnL
            // 
            //I changed button4 to btnL
            this.btnL.Location = new System.Drawing.Point(21, 155);
            //I changed the positioning
            this.btnL.Name = "btnL";
            this.btnL.Size = new System.Drawing.Size(93, 45);
            this.btnL.TabIndex = 2;
            //I added the hotkey
            this.btnL.Text = "&L";
            this.btnL.UseVisualStyleBackColor = true;
            this.btnL.Click += new System.EventHandler(this.btnL_Click);

            // 
            // button5
            // 
            //I added the DialogResult.Cancel
            this.button5.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button5.Location = new System.Drawing.Point(136, 234);
            this.button5.Name = "button5";
            //I changed the size
            this.button5.Size = new System.Drawing.Size(216, 97);
            this.button5.TabIndex = 4;
            //I added the hotkey
            this.button5.Text = "&Exit";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);

            // 
            // lblMessage
            // 
            //I changed the message to lblMessage
            this.lblMessage.BackColor = System.Drawing.Color.Yellow;
            //I changed the font size, font, and color
            this.lblMessage.Font = new System.Drawing.Font("Times New Roman", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblMessage.Location = new System.Drawing.Point(133, 16);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(219, 184);
            this.lblMessage.TabIndex = 5;
            this.lblMessage.Text = "label1";
            this.lblMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // 
            // Form1
            // 
            // I changed button2 to btnBlue, button3 to btnR, button4 to btnL
            // and the lable to lblMessage
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(481, 343);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.btnL);
            this.Controls.Add(this.btnR);
            this.Controls.Add(this.btnBlue);
            this.Controls.Add(this.btnRed);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion
        // I changed button2 to btnBlue, button3 to btnR, button4 to btnL
        // and the lable to lblMessage
        private System.Windows.Forms.Button btnRed;
        private System.Windows.Forms.Button btnBlue;
        private System.Windows.Forms.Button btnR;
        private System.Windows.Forms.Button btnL;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label lblMessage;
    }
}

