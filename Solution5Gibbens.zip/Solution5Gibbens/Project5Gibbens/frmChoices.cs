﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/* Name : Autumn Gibbens
 * Course : ITD 2343 – Object Oriented Programming with C#
 * Instructor: Mark L. Pranger
 * Due Date: October 4, 2025
 */

namespace Project5Gibbens
{
    public partial class frmChoices : Form
    {
        static void Main()
        {
            Application.Run(new frmChoices());
        }
        public frmChoices()
        {
            InitializeComponent();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lblMessage.Text = " ";
            txtLeft.Text = " ";
            txtRight.Text = " ";
            txtNumberCheck.Text = " ";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            // Converts all of the text boxes to intergers so that it is easier to use
            int numberCheck = Convert.ToInt32(txtNumberCheck.Text);
            int left = Convert.ToInt32(txtLeft.Text);
            int right = Convert.ToInt32(txtRight.Text);

            //Checks if the number is equal to the lower number and displays a 
            //message if it is.
            if (numberCheck == left)
            {
                lblMessage.Text = "The checked number is equal to the lower number";
            }
            //Checks if the number is equal to the higher number and displays a 
            //message if it is.
            else if (numberCheck == right)
            {
                lblMessage.Text = "The checked number is equal to the higher number";
            }
            //Checks if the number is less than the lower number and displays a 
            //message if it is.
            else if (numberCheck < left)
            {
                lblMessage.Text = "The checked number is less that the lower number";
            }
            //Checks if the number is higher than the lower number and displays a 
            //message if it is.
            else if (numberCheck > right)
            {
                lblMessage.Text = "The checked number is greater than the higher number";
            }
            // If the number is not any of the above then it is in the correct range
            // so there is a message that explains that.
            else 
            {
                lblMessage.Text = "The checked number is in the range of " +
                    txtLeft.Text + " and " + txtRight.Text;
            }

            //Clears the NumberCheck box and focuses on it
            txtNumberCheck.Text = " ";
            txtNumberCheck.Focus();
        }
    }
}
