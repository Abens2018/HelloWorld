﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace section3Project_Gibbens
{
    public partial class frmTextStatistics : Form
    {
        static void Main()
        {
            Application.Run(new frmTextStatistics());
        }
        public frmTextStatistics()
        {
            bool b = true;
            InitializeComponent();
            rdoWord.Checked = true;
            chkFrequency.Checked = false; 
            rdoUnique.Enabled = false;
            rdoWord.Enabled = false;
            chkFrequency.Enabled = false;
        }

        private int findSentencCount(string text)
        {
            int sentenceCount;
            string[] sentences = text.Split('.', '?', '!');
            sentenceCount = sentences.Count(s => !string.IsNullOrEmpty(s));
            return sentenceCount;
        }

        private int findCharacterCount(string text)
        {
            int characterCount;
            characterCount = text.Length;
            return characterCount;
        }

        private string[] findWordList(string text)
        {
            text = text.Replace(",", "")
                .Replace(";", "")
                .Replace(":", "")
                .Replace(".", "")
                .Replace("!", "")
                .Replace("?", "")
                .Replace("(", "")
                .Replace(")", "")
                .Replace("0", "")
                .Replace("1", "")
                .Replace("2", "")
                .Replace("3", "")
                .Replace("4", "")
                .Replace("5", "")
                .Replace("6", "")
                .Replace("7", "")
                .Replace("8", "")
                .Replace("9", "")
                .Replace("\"", "");
            text = text.ToLower();
            text = text.Trim();
            string[] wordList = text.Split(' ');
            Array.Sort(wordList);
            return wordList;
        }

        private string[] findUniqueWordList(string[] wordList)
        {
            string uniqueWordString = "";

            foreach (string word in wordList)
            {
                if (!uniqueWordString.Contains(" " + word + " "))
                {
                    uniqueWordString += word + " ";
                }
            }
            uniqueWordString = uniqueWordString.Trim();
            string[] uniqueWordList = uniqueWordString.Split(' ');
            return uniqueWordList;
        }

        private int[] findFrequency(string[] wordList, string[] uniqueWordList)
        {
            int[] frequency = new int[uniqueWordList.Length];

            for (int i = 0; i < uniqueWordList.Length; i++)
            {
                frequency[i] = 0;
            }
            foreach (string word in wordList)
            {
                int index = Array.IndexOf(uniqueWordList, word);
                frequency[index] += 1;
            }
            return frequency;
        }

        private int findAverage(string[] list)
        {
            int average = 0;
            int sum = 0;
            int total = list.Length;

            foreach (string word in list)
            {
                sum += word.Length;
            }
            average = sum / total;
            return average;
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            rchList.Text = "";
            rchText.Text = "";
            lblStatAverageUnique.Text = "";
            lblStatAverageWord.Text = "";
            lblStatCountCharcters.Text = "";
            lblStatCountSentences.Text = "";
            lblStatCountUnique.Text = "";
            lblStatCountWords.Text = "";
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            string text = rchText.Text;
            if (text == "")
            {
                string message = "You need to have text.";
                string caption = "Error";
                MessageBox.Show(message, caption);
            } else
            {
                rdoWord.Enabled = true;
                rdoUnique.Enabled = true;
                string[] wordList;
                string[] uniqueWordList;
                int[] frequency;
                int sentenceCount;
                int characterCount;

                rchList.Text = "";

                sentenceCount = findSentencCount(text);
                lblStatCountSentences.Text = sentenceCount.ToString();

                characterCount = findCharacterCount(text);
                lblStatCountCharcters.Text = characterCount.ToString();

                wordList = findWordList(text);
                foreach (string word in wordList)
                {
                    string wordTrim = word.Trim();
                    rchList.Text += wordTrim + "\n";
                }
                int wordCount = wordList.Count();
                lblStatCountWords.Text = wordCount.ToString();

                uniqueWordList = findUniqueWordList(wordList);
                frequency = findFrequency(wordList, uniqueWordList);
                if (rdoUnique.Checked)
                {
                    rchList.Text = "";
                    int index = 0;
                    foreach (string word in uniqueWordList)
                    {
                        if (chkFrequency.Checked)
                        {
                            string wordTrim = word.Trim();
                            rchList.Text += wordTrim + " " + frequency[index] + "\n";
                            index++;
                        }
                        else
                        {
                            string wordTrim = word.Trim();
                            rchList.Text += wordTrim + "\n";
                        }

                    }
                }
                int uniqueWordCount = uniqueWordList.Count();
                lblStatCountUnique.Text = uniqueWordCount.ToString();

                int averageWord = findAverage(wordList);
                lblStatAverageWord.Text = averageWord.ToString();

                int averageUnique = findAverage(uniqueWordList);
                lblStatAverageUnique.Text = averageUnique.ToString();
            }
        }

        private void rdoWord_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoWord.Checked)
            {
                chkFrequency.Checked = false;
                chkFrequency.Enabled = false;
            }
            else
            {
                chkFrequency.Enabled = true;
            }
        }

        private void rdoUnique_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
