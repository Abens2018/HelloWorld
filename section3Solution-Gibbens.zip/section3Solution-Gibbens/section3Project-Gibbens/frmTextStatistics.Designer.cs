﻿namespace section3Project_Gibbens
{
    partial class frmTextStatistics
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblStatCountSentences = new System.Windows.Forms.Label();
            this.lblStatCountWords = new System.Windows.Forms.Label();
            this.lblStatAverageUnique = new System.Windows.Forms.Label();
            this.lblStatCountUnique = new System.Windows.Forms.Label();
            this.lblStatAverageWord = new System.Windows.Forms.Label();
            this.lblStatCountCharcters = new System.Windows.Forms.Label();
            this.rchList = new System.Windows.Forms.RichTextBox();
            this.rchText = new System.Windows.Forms.RichTextBox();
            this.lblInformAverageUnique = new System.Windows.Forms.Label();
            this.lblInformCountUnique = new System.Windows.Forms.Label();
            this.lblInformCountWords = new System.Windows.Forms.Label();
            this.lblInformAverageWords = new System.Windows.Forms.Label();
            this.lblInformCountCharacters = new System.Windows.Forms.Label();
            this.lblInformCountSentence = new System.Windows.Forms.Label();
            this.lblStatistics = new System.Windows.Forms.Label();
            this.chkFrequency = new System.Windows.Forms.CheckBox();
            this.btnProcess = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.rdoWord = new System.Windows.Forms.RadioButton();
            this.rdoUnique = new System.Windows.Forms.RadioButton();
            this.grpOptions = new System.Windows.Forms.GroupBox();
            this.grpOptions.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblStatCountSentences
            // 
            this.lblStatCountSentences.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lblStatCountSentences.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatCountSentences.Location = new System.Drawing.Point(236, 473);
            this.lblStatCountSentences.Name = "lblStatCountSentences";
            this.lblStatCountSentences.Size = new System.Drawing.Size(153, 30);
            this.lblStatCountSentences.TabIndex = 11;
            this.lblStatCountSentences.Click += new System.EventHandler(this.label6_Click);
            // 
            // lblStatCountWords
            // 
            this.lblStatCountWords.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lblStatCountWords.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatCountWords.Location = new System.Drawing.Point(635, 473);
            this.lblStatCountWords.Name = "lblStatCountWords";
            this.lblStatCountWords.Size = new System.Drawing.Size(153, 30);
            this.lblStatCountWords.TabIndex = 13;
            // 
            // lblStatAverageUnique
            // 
            this.lblStatAverageUnique.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lblStatAverageUnique.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatAverageUnique.Location = new System.Drawing.Point(638, 578);
            this.lblStatAverageUnique.Name = "lblStatAverageUnique";
            this.lblStatAverageUnique.Size = new System.Drawing.Size(153, 30);
            this.lblStatAverageUnique.TabIndex = 18;
            // 
            // lblStatCountUnique
            // 
            this.lblStatCountUnique.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lblStatCountUnique.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatCountUnique.Location = new System.Drawing.Point(635, 526);
            this.lblStatCountUnique.Name = "lblStatCountUnique";
            this.lblStatCountUnique.Size = new System.Drawing.Size(153, 30);
            this.lblStatCountUnique.TabIndex = 19;
            // 
            // lblStatAverageWord
            // 
            this.lblStatAverageWord.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lblStatAverageWord.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatAverageWord.Location = new System.Drawing.Point(236, 578);
            this.lblStatAverageWord.Name = "lblStatAverageWord";
            this.lblStatAverageWord.Size = new System.Drawing.Size(153, 30);
            this.lblStatAverageWord.TabIndex = 20;
            // 
            // lblStatCountCharcters
            // 
            this.lblStatCountCharcters.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lblStatCountCharcters.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatCountCharcters.Location = new System.Drawing.Point(236, 526);
            this.lblStatCountCharcters.Name = "lblStatCountCharcters";
            this.lblStatCountCharcters.Size = new System.Drawing.Size(153, 30);
            this.lblStatCountCharcters.TabIndex = 21;
            // 
            // rchList
            // 
            this.rchList.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.rchList.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchList.Location = new System.Drawing.Point(16, 9);
            this.rchList.Name = "rchList";
            this.rchList.ReadOnly = true;
            this.rchList.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.rchList.Size = new System.Drawing.Size(197, 250);
            this.rchList.TabIndex = 22;
            this.rchList.Text = "";
            // 
            // rchText
            // 
            this.rchText.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.rchText.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchText.Location = new System.Drawing.Point(236, 9);
            this.rchText.Name = "rchText";
            this.rchText.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.rchText.Size = new System.Drawing.Size(552, 250);
            this.rchText.TabIndex = 0;
            this.rchText.Text = "";
            // 
            // lblInformAverageUnique
            // 
            this.lblInformAverageUnique.BackColor = System.Drawing.Color.Snow;
            this.lblInformAverageUnique.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInformAverageUnique.Location = new System.Drawing.Point(405, 578);
            this.lblInformAverageUnique.Name = "lblInformAverageUnique";
            this.lblInformAverageUnique.Size = new System.Drawing.Size(227, 30);
            this.lblInformAverageUnique.TabIndex = 17;
            this.lblInformAverageUnique.Text = "Average Length Unique:";
            // 
            // lblInformCountUnique
            // 
            this.lblInformCountUnique.BackColor = System.Drawing.Color.Snow;
            this.lblInformCountUnique.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInformCountUnique.Location = new System.Drawing.Point(405, 526);
            this.lblInformCountUnique.Name = "lblInformCountUnique";
            this.lblInformCountUnique.Size = new System.Drawing.Size(215, 30);
            this.lblInformCountUnique.TabIndex = 14;
            this.lblInformCountUnique.Text = "Number of Unique: ";
            this.lblInformCountUnique.Click += new System.EventHandler(this.label9_Click);
            // 
            // lblInformCountWords
            // 
            this.lblInformCountWords.BackColor = System.Drawing.Color.Snow;
            this.lblInformCountWords.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInformCountWords.Location = new System.Drawing.Point(405, 473);
            this.lblInformCountWords.Name = "lblInformCountWords";
            this.lblInformCountWords.Size = new System.Drawing.Size(215, 30);
            this.lblInformCountWords.TabIndex = 12;
            this.lblInformCountWords.Text = "Number of Words: ";
            // 
            // lblInformAverageWords
            // 
            this.lblInformAverageWords.BackColor = System.Drawing.Color.Snow;
            this.lblInformAverageWords.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInformAverageWords.Location = new System.Drawing.Point(15, 578);
            this.lblInformAverageWords.Name = "lblInformAverageWords";
            this.lblInformAverageWords.Size = new System.Drawing.Size(215, 30);
            this.lblInformAverageWords.TabIndex = 15;
            this.lblInformAverageWords.Text = "Average Length Word:";
            // 
            // lblInformCountCharacters
            // 
            this.lblInformCountCharacters.BackColor = System.Drawing.Color.Snow;
            this.lblInformCountCharacters.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInformCountCharacters.Location = new System.Drawing.Point(16, 526);
            this.lblInformCountCharacters.Name = "lblInformCountCharacters";
            this.lblInformCountCharacters.Size = new System.Drawing.Size(215, 30);
            this.lblInformCountCharacters.TabIndex = 16;
            this.lblInformCountCharacters.Text = "Number of Characters: ";
            // 
            // lblInformCountSentence
            // 
            this.lblInformCountSentence.BackColor = System.Drawing.Color.Snow;
            this.lblInformCountSentence.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInformCountSentence.Location = new System.Drawing.Point(12, 473);
            this.lblInformCountSentence.Name = "lblInformCountSentence";
            this.lblInformCountSentence.Size = new System.Drawing.Size(215, 30);
            this.lblInformCountSentence.TabIndex = 10;
            this.lblInformCountSentence.Text = "Number of Sentences: ";
            // 
            // lblStatistics
            // 
            this.lblStatistics.BackColor = System.Drawing.Color.Snow;
            this.lblStatistics.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatistics.Location = new System.Drawing.Point(16, 427);
            this.lblStatistics.Name = "lblStatistics";
            this.lblStatistics.Size = new System.Drawing.Size(197, 30);
            this.lblStatistics.TabIndex = 9;
            this.lblStatistics.Text = "Statistics";
            // 
            // chkFrequency
            // 
            this.chkFrequency.AutoSize = true;
            this.chkFrequency.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkFrequency.Location = new System.Drawing.Point(15, 382);
            this.chkFrequency.Name = "chkFrequency";
            this.chkFrequency.Size = new System.Drawing.Size(158, 24);
            this.chkFrequency.TabIndex = 5;
            this.chkFrequency.Text = "Frequency Count";
            this.chkFrequency.UseVisualStyleBackColor = true;
            // 
            // btnProcess
            // 
            this.btnProcess.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProcess.Location = new System.Drawing.Point(617, 276);
            this.btnProcess.Name = "btnProcess";
            this.btnProcess.Size = new System.Drawing.Size(171, 134);
            this.btnProcess.TabIndex = 3;
            this.btnProcess.Text = "&Process";
            this.btnProcess.UseVisualStyleBackColor = true;
            this.btnProcess.Click += new System.EventHandler(this.btnProcess_Click);
            // 
            // btnReset
            // 
            this.btnReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(427, 276);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(171, 134);
            this.btnReset.TabIndex = 2;
            this.btnReset.Text = "&Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(241, 276);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(171, 134);
            this.btnExit.TabIndex = 1;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // rdoWord
            // 
            this.rdoWord.AutoSize = true;
            this.rdoWord.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoWord.Location = new System.Drawing.Point(6, 19);
            this.rdoWord.Name = "rdoWord";
            this.rdoWord.Size = new System.Drawing.Size(149, 24);
            this.rdoWord.TabIndex = 0;
            this.rdoWord.TabStop = true;
            this.rdoWord.Text = "Show Word List";
            this.rdoWord.UseVisualStyleBackColor = true;
            this.rdoWord.CheckedChanged += new System.EventHandler(this.rdoWord_CheckedChanged);
            // 
            // rdoUnique
            // 
            this.rdoUnique.AutoSize = true;
            this.rdoUnique.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoUnique.Location = new System.Drawing.Point(6, 49);
            this.rdoUnique.Name = "rdoUnique";
            this.rdoUnique.Size = new System.Drawing.Size(206, 24);
            this.rdoUnique.TabIndex = 1;
            this.rdoUnique.TabStop = true;
            this.rdoUnique.Text = "Show Unique Word List";
            this.rdoUnique.UseVisualStyleBackColor = true;
            this.rdoUnique.CheckedChanged += new System.EventHandler(this.rdoUnique_CheckedChanged);
            // 
            // grpOptions
            // 
            this.grpOptions.Controls.Add(this.rdoUnique);
            this.grpOptions.Controls.Add(this.rdoWord);
            this.grpOptions.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpOptions.Location = new System.Drawing.Point(15, 276);
            this.grpOptions.Name = "grpOptions";
            this.grpOptions.Size = new System.Drawing.Size(215, 100);
            this.grpOptions.TabIndex = 4;
            this.grpOptions.TabStop = false;
            this.grpOptions.Text = "Word List Options";
            // 
            // frmTextStatistics
            // 
            this.AcceptButton = this.btnProcess;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Snow;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(800, 629);
            this.Controls.Add(this.rchText);
            this.Controls.Add(this.rchList);
            this.Controls.Add(this.lblStatCountCharcters);
            this.Controls.Add(this.lblStatAverageWord);
            this.Controls.Add(this.lblStatCountUnique);
            this.Controls.Add(this.lblStatAverageUnique);
            this.Controls.Add(this.lblInformAverageUnique);
            this.Controls.Add(this.lblInformCountCharacters);
            this.Controls.Add(this.lblInformAverageWords);
            this.Controls.Add(this.lblInformCountUnique);
            this.Controls.Add(this.lblStatCountWords);
            this.Controls.Add(this.lblInformCountWords);
            this.Controls.Add(this.lblStatCountSentences);
            this.Controls.Add(this.lblInformCountSentence);
            this.Controls.Add(this.lblStatistics);
            this.Controls.Add(this.chkFrequency);
            this.Controls.Add(this.btnProcess);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.grpOptions);
            this.Name = "frmTextStatistics";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Text Statistics";
            this.grpOptions.ResumeLayout(false);
            this.grpOptions.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblStatCountSentences;
        private System.Windows.Forms.Label lblStatCountWords;
        private System.Windows.Forms.Label lblStatAverageUnique;
        private System.Windows.Forms.Label lblStatCountUnique;
        private System.Windows.Forms.Label lblStatAverageWord;
        private System.Windows.Forms.Label lblStatCountCharcters;
        private System.Windows.Forms.RichTextBox rchList;
        private System.Windows.Forms.RichTextBox rchText;
        private System.Windows.Forms.Label lblInformAverageUnique;
        private System.Windows.Forms.Label lblInformCountUnique;
        private System.Windows.Forms.Label lblInformCountWords;
        private System.Windows.Forms.Label lblInformAverageWords;
        private System.Windows.Forms.Label lblInformCountCharacters;
        private System.Windows.Forms.Label lblInformCountSentence;
        private System.Windows.Forms.Label lblStatistics;
        private System.Windows.Forms.CheckBox chkFrequency;
        private System.Windows.Forms.Button btnProcess;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.RadioButton rdoWord;
        private System.Windows.Forms.RadioButton rdoUnique;
        private System.Windows.Forms.GroupBox grpOptions;
    }
}