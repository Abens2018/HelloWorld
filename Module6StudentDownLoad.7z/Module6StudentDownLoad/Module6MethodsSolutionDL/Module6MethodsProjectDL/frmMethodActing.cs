﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/* Name : Autumn Gibbens
 * Course : ITD 2343 – Object Oriented Programming with C#
 * Instructor: Mark L. Pranger
 * Due Date: October 15, 2025
 */

namespace Module6MethodsProjectDL
{
    public partial class frmMethodActing : Form
    {
        // Public Contsants to use
        const byte ADD = 0;
        const byte SUBTRACT = 1;
        const byte MULTIPLY = 2;
        const byte DIVIDE = 3;
        const byte MODULUS = 4;

        public frmMethodActing()
        {
            InitializeComponent();
        }

        //Put Your method here
        private decimal CalculateButtons(int type, decimal numLeft, decimal numRight)
        {
            decimal result = 0;

            if (type == 0)
            {
                result = numLeft + numRight;
            }
            else if (type == 1)
            {
                result = numLeft - numRight;
            }
            else if (type == 2)
            {
                result = numLeft * numRight;
            }
            else if (type == 3)
            {
                result = numLeft / numRight;
            }
            else
            {
                result = numLeft % numRight;
            }

            return result;
        }
        private void button5_Click(object sender, EventArgs e)
        {
            decimal dLeft = 0.0m;
            decimal dRight = 0.0m;
            decimal dAnswer = 0.0m;
            string szLeft = "";
            string szRight = "";
            string szAnswer = "";
            string szEquation = "";

            szLeft = txtLeft.Text;
            szRight = txtRight.Text;

            dLeft = Convert.ToDecimal(szLeft);
            dRight = Convert.ToDecimal(szRight);

            dAnswer = CalculateButtons(MODULUS, dLeft, dRight);

            szAnswer = dAnswer.ToString();

            szEquation = szLeft + " % " + szRight + " = " + szAnswer;

            lblAnswer.Text = "";
            lblAnswer.Text = szEquation;


        }

        private void button4_Click(object sender, EventArgs e)
        {
            decimal dLeft = 0.0m;
            decimal dRight = 0.0m;
            decimal dAnswer = 0.0m;
            string szLeft = "";
            string szRight = "";
            string szAnswer = "";
            string szEquation = "";

            szLeft = txtLeft.Text;
            szRight = txtRight.Text;

            dLeft = Convert.ToDecimal(szLeft);
            dRight = Convert.ToDecimal(szRight);

            dAnswer = CalculateButtons(DIVIDE, dLeft, dRight);

            szAnswer = dAnswer.ToString();

            szEquation = szLeft + " / " + szRight + " = " + szAnswer;

            lblAnswer.Text = "";
            lblAnswer.Text = szEquation;


        }

        private void button3_Click(object sender, EventArgs e)
        {
            decimal dLeft = 0.0m;
            decimal dRight = 0.0m;
            decimal dAnswer = 0.0m;
            string szLeft = "";
            string szRight = "";
            string szAnswer = "";
            string szEquation = "";

            szLeft = txtLeft.Text;
            szRight = txtRight.Text;

            dLeft = Convert.ToDecimal(szLeft);
            dRight = Convert.ToDecimal(szRight);

            dAnswer = CalculateButtons(MULTIPLY, dLeft, dRight);

            szAnswer = dAnswer.ToString();

            szEquation = szLeft + " * " + szRight + " = " + szAnswer;

            lblAnswer.Text = "";
            lblAnswer.Text = szEquation;


        }

        private void button2_Click(object sender, EventArgs e)
        {
            decimal dLeft = 0.0m;
            decimal dRight = 0.0m;
            decimal dAnswer = 0.0m;
            string szLeft = "";
            string szRight = "";
            string szAnswer = "";
            string szEquation = "";

            szLeft = txtLeft.Text;
            szRight = txtRight.Text;

            dLeft = Convert.ToDecimal(szLeft);
            dRight = Convert.ToDecimal(szRight);

            dAnswer = CalculateButtons(SUBTRACT, dLeft, dRight);

            szAnswer = dAnswer.ToString();

            szEquation = szLeft + " - " + szRight + " = " + szAnswer;

            lblAnswer.Text = "";
            lblAnswer.Text = szEquation;


        }

        private void button1_Click(object sender, EventArgs e)
        {
            decimal dLeft = 0.0m;
            decimal dRight = 0.0m;
            decimal dAnswer = 0.0m;
            string szLeft = "";
            string szRight = "";
            string szAnswer = "";
            string szEquation = "";

            szLeft = txtLeft.Text;
            szRight = txtRight.Text;

            dLeft = Convert.ToDecimal(szLeft);
            dRight = Convert.ToDecimal(szRight);

            dAnswer = CalculateButtons(ADD, dLeft, dRight);

            szAnswer = dAnswer.ToString();

            szEquation = szLeft + " + " + szRight + " = " + szAnswer;

            lblAnswer.Text = "";
            lblAnswer.Text = szEquation;

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtLeft.Text = " ";
            txtRight.Text = " ";
            lblAnswer.Text = " ";
        }
    }
}
