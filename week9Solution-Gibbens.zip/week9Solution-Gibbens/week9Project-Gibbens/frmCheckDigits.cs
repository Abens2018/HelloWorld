﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

/* Name : Autumn Gibbens
 * Course : ITD 2343 – Object Oriented Programming with C#
 * Instructor: Mark L. Pranger
 * Due Date: November 7, 2025
 */

namespace week9Project_Gibbens
{
    public partial class frmCheckDigits : Form
    {
        static void Main()
        {
            Application.Run(new frmCheckDigits());
        }

        public frmCheckDigits()
        {
            InitializeComponent();
        }

        private bool errorAccount(string accountString, string confirmString)
        {
            if (accountString == "")
            {
                lblMessage.Text = "An account number is necessary. ";
                return false;
            }

            if (accountString != confirmString)
            {
                lblMessage.Text = "The account number and the confirmation " +
                    "number needs to be the same. ";
                return false;
            }

            if (accountString.Length != 8)
            {
                lblMessage.Text = "The account number needs to " +
                    "be Eight digits long. ";
                return false;
            }
            try
            {
                int accountNumber = Convert.ToInt32(accountString);
                
                int length = accountString.Length;
                int total = 0;
                int counter = 0;

                while (counter < length - 1)
                {

                    total += int.Parse(accountString[counter].ToString());
                    counter++;
                }
                int check = total % 10;
                if (check != int.Parse(accountString[counter].ToString()))
                {
                    lblMessage.Text = "The account number is not valid. ";
                    return false;
                }
                else
                {
                    return true;
                }
            }
            catch (Exception)
            {
                lblMessage.Text = "The account number needs to be a number. ";
                return false;
            }
        }
        private bool errorPayment(string paymentString)
        {
            if (paymentString == "")
            {
                lblMessage.Text += "A payment amount is necessary.";
                return false;                
            }

            
            if (decimal.TryParse(paymentString,
                NumberStyles.AllowCurrencySymbol | NumberStyles.AllowDecimalPoint |
                NumberStyles.AllowThousands,
                CultureInfo.CurrentCulture, out decimal paymentNumber))
            {
                return true;
            }
            else
            {
                lblMessage.Text += "The payment needs to be a valid number.";
                return false;
            }
        }
        private decimal paymentConverter(string paymentString)
        {
            if (paymentString == "")
            {
                lblMessage.Text += "A payment amount is necessary.";
            }


            if (decimal.TryParse(paymentString,
                NumberStyles.AllowCurrencySymbol | NumberStyles.AllowDecimalPoint |
                NumberStyles.AllowThousands,
                CultureInfo.CurrentCulture, out decimal paymentNumber))
            {
                return paymentNumber;
            }
            else
            {
                paymentNumber = 0;
                return paymentNumber;
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtAccount.Text = "";
            txtConfirm.Text = "";
            txtPayment.Text = "";
            lblMessage.Text = "";
            txtAccount.Focus();
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            string accountString;
            string confirmString;
            string paymentString;

            lblMessage.Text = "";

            accountString = txtAccount.Text;
            confirmString = txtConfirm.Text;
            paymentString = txtPayment.Text;

            bool errorVarAccount = errorAccount(accountString, confirmString);
            bool errorVarPayment = errorPayment(paymentString);

            if (errorVarAccount == true && errorVarPayment == true)
            {
                decimal paymentNumber = paymentConverter(paymentString);
                if (paymentNumber == 0)
                {
                    lblMessage.Text += "The payment needs to be a valid number.";
                } else
                {
                    DateTime currentDate = DateTime.Now;
                    string paymentDate = String.Format("{0:MMMM d}", currentDate);
                    lblMessage.Text = "A payment of $" + paymentNumber + 
                        " was applied to account " + accountString +
                        " on " + paymentDate;
                }
            }

        }
    }
}
