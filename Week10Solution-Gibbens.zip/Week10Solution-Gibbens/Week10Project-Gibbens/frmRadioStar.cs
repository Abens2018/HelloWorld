﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/* Name : Autumn Gibbens
 * Course : ITD 2343 – Object Oriented Programming with C#
 * Instructor: Mark L. Pranger
 * Due Date: November 11, 2025
 */

namespace Week10Project_Gibbens
{
    public partial class frmRadioStar : Form
    {
        static void Main()
        {
            Application.Run(new frmRadioStar());
        }
        public frmRadioStar()
        {
            InitializeComponent();
            rdoAddition.Checked = true;
            chkVerbos.Checked = true;
            txtNumber1.Focus();
        }

    
        private bool errorCalculate1(string string1)
        {
            if (string1 == "")
            {
                lblMessage.Text = "The first text box cannot be empty. ";
                return false;
            }

            try
            {
                int num1 = Convert.ToInt32(txtNumber1.Text);
                return true;
            }
            catch (Exception)
            {
                lblMessage.Text = "The first text box need to needs to be a number. ";
                return false;
            }
        }

        private bool errorCalculate2(string string2)
        {
            if (string2 == "")
            {
                lblMessage.Text += "The second text box cannot be empty. ";
                return false;
            }

            try
            {
                int num2 = Convert.ToInt32(txtNumber2.Text);
                if (rdoDivision.Checked)
                {
                    if (num2 == 0)
                    {
                        lblMessage.Text += "You cannot divide by zero. ";
                        return false;
                    }
                }
                if (rdoModulus.Checked)
                {
                    if (num2 == 0)
                    {
                        lblMessage.Text += "You cannot modulus by zero. ";
                        return false;
                    }
                    else if (num2 < 0)
                    {
                        lblMessage.Text += "You cannot modulus by less than zero. ";
                        return false;
                    }
                }
                return true;

            }
            catch (Exception)
            {
                lblMessage.Text += "The second text box need to needs to be a number. ";
                return false;
            }
        }

        private int calculateResults(int num1, int num2)
        {
            int results = 0;
            if (rdoAddition.Checked)
            {
                results = num1 + num2;
            }
            else if (rdoSubtration.Checked)
            {
                results = num1 - num2;
            }
            else if (rdoMultiplication.Checked)
            {
                results = num1 * num2;
            }
            else if (rdoDivision.Checked)
            {
                results = num1 / num2;
            }
            else if (rdoModulus.Checked)
            {
                results = num1 % num2;
            }
            return results;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            lblMessage.Text = "";
            txtNumber1.Text = "";
            txtNumber2.Text = "";
            rdoAddition.Checked = true;
            chkVerbos.Checked = true;
            txtNumber1.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            lblMessage.Text = "";

            string string1 = txtNumber1.Text;
            string string2 = txtNumber2.Text;
            string opperation = "";
            int num1 = 0;
            int num2 = 0;
            int results = 0;

            ///Add method for errors
            bool noError1 = errorCalculate1(string1);
            bool noError2 = errorCalculate2(string2);

            if (noError1 && noError2)
            {
                num1 = Convert.ToInt32(txtNumber1.Text);
                num2 = Convert.ToInt32(txtNumber2.Text);

                results = calculateResults(num1, num2);

                if (rdoAddition.Checked)
                {
                    opperation = "+";
                }
                else if (rdoSubtration.Checked)
                {
                    opperation = "-";
                }
                else if (rdoMultiplication.Checked)
                {
                    opperation = "*";
                }
                else if (rdoDivision.Checked)
                {
                    opperation = "/";
                }
                else if (rdoModulus.Checked)
                {
                    opperation = "%";
                }

                if (chkVerbos.Checked)
                {
                    lblMessage.Text = num1 + " " + opperation + " " + num2 + " = " + results;
                }
                else
                {
                    lblMessage.Text = "The answer is " + results;
                }
            }
        }
    }
}
