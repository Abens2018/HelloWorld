﻿namespace Week10Project_Gibbens
{
    partial class frmRadioStar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNumber1 = new System.Windows.Forms.Label();
            this.lblNumber2 = new System.Windows.Forms.Label();
            this.txtNumber1 = new System.Windows.Forms.TextBox();
            this.txtNumber2 = new System.Windows.Forms.TextBox();
            this.rdoMultiplication = new System.Windows.Forms.RadioButton();
            this.grpMathOps = new System.Windows.Forms.GroupBox();
            this.rdoDivision = new System.Windows.Forms.RadioButton();
            this.rdoModulus = new System.Windows.Forms.RadioButton();
            this.rdoSubtration = new System.Windows.Forms.RadioButton();
            this.rdoAddition = new System.Windows.Forms.RadioButton();
            this.lblMessage = new System.Windows.Forms.Label();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.chkVerbos = new System.Windows.Forms.CheckBox();
            this.grpMathOps.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNumber1
            // 
            this.lblNumber1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumber1.Location = new System.Drawing.Point(12, 26);
            this.lblNumber1.Name = "lblNumber1";
            this.lblNumber1.Size = new System.Drawing.Size(110, 31);
            this.lblNumber1.TabIndex = 0;
            this.lblNumber1.Text = "Operand 1";
            // 
            // lblNumber2
            // 
            this.lblNumber2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumber2.Location = new System.Drawing.Point(12, 75);
            this.lblNumber2.Name = "lblNumber2";
            this.lblNumber2.Size = new System.Drawing.Size(110, 31);
            this.lblNumber2.TabIndex = 1;
            this.lblNumber2.Text = "Operand 2";
            // 
            // txtNumber1
            // 
            this.txtNumber1.BackColor = System.Drawing.Color.LightYellow;
            this.txtNumber1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumber1.Location = new System.Drawing.Point(221, 26);
            this.txtNumber1.Name = "txtNumber1";
            this.txtNumber1.Size = new System.Drawing.Size(218, 30);
            this.txtNumber1.TabIndex = 2;
            // 
            // txtNumber2
            // 
            this.txtNumber2.BackColor = System.Drawing.Color.LightYellow;
            this.txtNumber2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumber2.Location = new System.Drawing.Point(221, 75);
            this.txtNumber2.Name = "txtNumber2";
            this.txtNumber2.Size = new System.Drawing.Size(218, 30);
            this.txtNumber2.TabIndex = 3;
            // 
            // rdoMultiplication
            // 
            this.rdoMultiplication.AutoSize = true;
            this.rdoMultiplication.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoMultiplication.Location = new System.Drawing.Point(10, 58);
            this.rdoMultiplication.Name = "rdoMultiplication";
            this.rdoMultiplication.Size = new System.Drawing.Size(98, 24);
            this.rdoMultiplication.TabIndex = 4;
            this.rdoMultiplication.TabStop = true;
            this.rdoMultiplication.Text = "Multiply *";
            this.rdoMultiplication.UseVisualStyleBackColor = true;
            // 
            // grpMathOps
            // 
            this.grpMathOps.Controls.Add(this.rdoAddition);
            this.grpMathOps.Controls.Add(this.rdoSubtration);
            this.grpMathOps.Controls.Add(this.rdoModulus);
            this.grpMathOps.Controls.Add(this.rdoDivision);
            this.grpMathOps.Controls.Add(this.rdoMultiplication);
            this.grpMathOps.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.grpMathOps.Location = new System.Drawing.Point(17, 130);
            this.grpMathOps.Name = "grpMathOps";
            this.grpMathOps.Size = new System.Drawing.Size(422, 100);
            this.grpMathOps.TabIndex = 5;
            this.grpMathOps.TabStop = false;
            this.grpMathOps.Text = "Math Operations Available";
            // 
            // rdoDivision
            // 
            this.rdoDivision.AutoSize = true;
            this.rdoDivision.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoDivision.Location = new System.Drawing.Point(154, 58);
            this.rdoDivision.Name = "rdoDivision";
            this.rdoDivision.Size = new System.Drawing.Size(87, 24);
            this.rdoDivision.TabIndex = 5;
            this.rdoDivision.TabStop = true;
            this.rdoDivision.Text = "Divide /";
            this.rdoDivision.UseVisualStyleBackColor = true;
            // 
            // rdoModulus
            // 
            this.rdoModulus.AutoSize = true;
            this.rdoModulus.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoModulus.Location = new System.Drawing.Point(300, 58);
            this.rdoModulus.Name = "rdoModulus";
            this.rdoModulus.Size = new System.Drawing.Size(113, 24);
            this.rdoModulus.TabIndex = 6;
            this.rdoModulus.TabStop = true;
            this.rdoModulus.Text = "Modulus %";
            this.rdoModulus.UseVisualStyleBackColor = true;
            // 
            // rdoSubtration
            // 
            this.rdoSubtration.AutoSize = true;
            this.rdoSubtration.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoSubtration.Location = new System.Drawing.Point(235, 28);
            this.rdoSubtration.Name = "rdoSubtration";
            this.rdoSubtration.Size = new System.Drawing.Size(104, 24);
            this.rdoSubtration.TabIndex = 7;
            this.rdoSubtration.TabStop = true;
            this.rdoSubtration.Text = "Subtract -";
            this.rdoSubtration.UseVisualStyleBackColor = true;
            // 
            // rdoAddition
            // 
            this.rdoAddition.AutoSize = true;
            this.rdoAddition.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoAddition.Location = new System.Drawing.Point(74, 28);
            this.rdoAddition.Name = "rdoAddition";
            this.rdoAddition.Size = new System.Drawing.Size(79, 24);
            this.rdoAddition.TabIndex = 8;
            this.rdoAddition.TabStop = true;
            this.rdoAddition.Text = "Add + ";
            this.rdoAddition.UseVisualStyleBackColor = true;
            // 
            // lblMessage
            // 
            this.lblMessage.BackColor = System.Drawing.Color.MistyRose;
            this.lblMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.Location = new System.Drawing.Point(16, 344);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(422, 216);
            this.lblMessage.TabIndex = 6;
            // 
            // btnReset
            // 
            this.btnReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(22, 236);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(121, 51);
            this.btnReset.TabIndex = 7;
            this.btnReset.Text = "&Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(171, 236);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(121, 51);
            this.btnExit.TabIndex = 8;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnCalculate
            // 
            this.btnCalculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalculate.Location = new System.Drawing.Point(318, 236);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(121, 51);
            this.btnCalculate.TabIndex = 9;
            this.btnCalculate.Text = "&Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // chkVerbos
            // 
            this.chkVerbos.AutoSize = true;
            this.chkVerbos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.chkVerbos.Location = new System.Drawing.Point(341, 302);
            this.chkVerbos.Name = "chkVerbos";
            this.chkVerbos.Size = new System.Drawing.Size(97, 29);
            this.chkVerbos.TabIndex = 10;
            this.chkVerbos.Text = "Verbos";
            this.chkVerbos.UseVisualStyleBackColor = true;
            // 
            // frmRadioStar
            // 
            this.AcceptButton = this.btnCalculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(451, 569);
            this.Controls.Add(this.chkVerbos);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.grpMathOps);
            this.Controls.Add(this.txtNumber2);
            this.Controls.Add(this.txtNumber1);
            this.Controls.Add(this.lblNumber2);
            this.Controls.Add(this.lblNumber1);
            this.Name = "frmRadioStar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Radio Buttons In Action";
            this.grpMathOps.ResumeLayout(false);
            this.grpMathOps.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNumber1;
        private System.Windows.Forms.Label lblNumber2;
        private System.Windows.Forms.TextBox txtNumber1;
        private System.Windows.Forms.TextBox txtNumber2;
        private System.Windows.Forms.RadioButton rdoMultiplication;
        private System.Windows.Forms.GroupBox grpMathOps;
        private System.Windows.Forms.RadioButton rdoAddition;
        private System.Windows.Forms.RadioButton rdoSubtration;
        private System.Windows.Forms.RadioButton rdoModulus;
        private System.Windows.Forms.RadioButton rdoDivision;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.CheckBox chkVerbos;
    }
}